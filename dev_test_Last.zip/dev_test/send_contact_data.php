<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


/**get in post */
$NameEmailSend = $_POST['name'];
$MiddleNameEmailSend = $_POST['second_name'];
$EmailSend = $_POST['email'];
$ReasonEmailSend = $_POST['reason'];
$MessageEmailSend = $_POST['message'];

/**Date Information */
$dateDataSender = date('l jS \of F Y h:i:s A');

$mail = new PHPMailer;
//Tell PHPMailer to use SMTP
$mail->isSMTP();
//Enable SMTP debugging
// 0 = off (for production use)
// 1 = client messages
// 2 = client and server messages
$mail->SMTPDebug = 0;
//Set the hostname of the mail server
$mail->Host = 'mail.supremecluster.com';
//Set the SMTP port number - likely to be 25, 465 or 587
$mail->Port = '2525';
//Whether to use SMTP authentication
$mail->SMTPAuth = true;
$mail->SMTPSecure = false;
//Username to use for SMTP authentication
$mail->Username = 'test@info-mat.com';
//Password to use for SMTP authentication
$mail->Password = '@testingEmail123456#';
//Set who the message is to be sent from
$mail->setFrom('test@info-mat.com', 'Email sending Test');
//Set an alternative reply-to address
//$mail->addReplyTo(''.$emailReplySmtp.'', ''.$titleReplySmtp.'');
//Set who the message is to be sent to
$mail->addAddress('alexanderquiroz@info-mat.com', 'Alexander Quiroz');
//Set the subject line
$mail->addCC('' . $EmailSend . '');
//$mail->addBCC('copia_oculta@outlook.com');
$mail->Subject = 'Contact email details';
//Read an HTML message body from an external file, convert referenced images to embedded,
//convert HTML into a basic plain-text alternative body
$mail->msgHTML('<html>
<head>
<title>Contact email details</title>
</head>
<body style="margin:0px; background: #f8f8f8; ">
<div width="100%" style="background: #f8f8f8; padding: 0px 0px; font-family:arial; line-height:28px; height:100%;  width: 100%; color: #514d6a;">
  <div style="max-width: 700px; padding:50px 0;  margin: 0px auto; font-size: 14px">
    <table border="0" cellpadding="0" cellspacing="0" style="width: 100%; margin-bottom: 20px">
      <tbody>
        <tr>
          <td style="vertical-align: top; padding-bottom:30px;" align="center"><a href="" target="_blank"><img src="' . HOME_URL . '/images/logo.png" alt=""><br/>
            </a> </td>
        </tr>
      </tbody>
    </table>
    <div style="padding: 40px; background: #fff;">
      <table border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
        <tbody>
          <tr>
            <td><b>Details of the sent mail</b>
              <ul>
              <li><b>Name: </b> ' . $NameEmailSend . '</li>
              <li><b>Middle Name:</b> ' . $MiddleNameEmailSend . '</li>
              <li><b>Email:</b> ' . $EmailSend . '</li>
              <li><b>Reason For Contact:</b> ' . $ReasonEmailSend . '</li>
              <li><b>Message:</b> ' . $MessageEmailSend . '</li>
              </ul>
              <b>' . $dateDataSender . '</b>
              
              </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div style="text-align: center; font-size: 12px; color: #b2b2b5; margin-top: 20px">
    </div>
  </div>
</div>
</body>
</html>');
//Replace the plain text body with one created manually
//$mail->AltBody = 'This is a plain-text message body';
//Attach an image file
//$mail->addAttachment('images/phpmailer_mini.png');
//send the message, check for errors

if (!$mail->send()) {
  $errorSend = $mail->ErrorInfo;
  echo 'Error sending mail, try again' . $errorSend;
} else {
  echo 'Mail sent successfully, I will be getting in touch with you as soon as possible, Thank you';
}
